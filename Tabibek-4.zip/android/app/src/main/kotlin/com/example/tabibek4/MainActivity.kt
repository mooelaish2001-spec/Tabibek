package com.example.tabibek4

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
